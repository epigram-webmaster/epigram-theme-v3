// Theme Config, check the documentation before edit this file

var theme_config = {
	flickr_id: '46776802@N03', // You can get it here: http://idgettr.com/
	flickr_photos_limit: 6, // How many photos you want to show
};

